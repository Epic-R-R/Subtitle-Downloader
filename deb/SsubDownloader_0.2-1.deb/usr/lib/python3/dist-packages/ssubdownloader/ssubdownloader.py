from bs4 import BeautifulSoup
from PyInquirer import style_from_dict, Token, prompt
from urllib.parse import urlparse
from pyfiglet import Figlet
from pathlib import Path
import os.path
import requests
import os
import sys
import wget
import time
import platform
import json
import datetime
import base64

PLATFORM = platform.system()

base_url = "https://worldsubtitle.info/page/"


# create class for terminal color
class bcolors:
    GREEN = '\033[32m'
    HEADER = '\033[95m'
    MAGENTA = '\033[35m'
    OKBLUE = '\033[94m'
    BLUE = '\033[34m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


style = style_from_dict({
    Token.QuestionMark: '#E91E63 bold',
    Token.Selected: '#673AB7 bold',
    Token.Instruction: '',  # default
    Token.Answer: '#2196f3 bold',
    Token.Question: '',
})


def screencls():
    if PLATFORM == "Linux" or PLATFORM == "Darwin":
        os.system('clear')
    if PLATFORM == "Windows":
        os.system('cls')


def get_new_subtitles(firsttime):
    if firsttime != True:
        movietitle = []
        seriestitle = []
        for i in range(2, 5):
            reqmovies = requests.get(f"https://worldsubtitle.info/category/movies/page/{i}")
            reqseries = requests.get(f"https://worldsubtitle.info/category/tv-series/page/{i}")
            soupmovies = BeautifulSoup(reqmovies.content, 'html.parser')
            soupseries = BeautifulSoup(reqseries.content, 'html.parser')
            for div in soupmovies.find_all('div', class_='cat-post-titel'):
                for a in div.find_all('a'):
                    movietitle.append(a.get_text())
            for div in soupseries.find_all('div', class_='cat-post-titel'):
                for a in div.find_all('a'):
                    seriestitle.append(a.get_text())
        for i in range(len(movietitle)):
            movietitle[i] = remove(movietitle[i])
        for i in range(len(seriestitle)):
            seriestitle[i] = remove(seriestitle[i])
        with open(f'{str(Path.home())}/.downloads.json', 'r') as fp:
            before = json.load(fp)
        oldmovie = before['historymovie'][0]
        # print(oldmovie)
        numbermovie = 0
        oldseries = before['historyseries'][0]
        numberseries = 0
        if set(movietitle) == set(oldmovie):
            return len(movietitle), len(seriestitle), '0'
        else:
            for i in range(len(oldmovie)):
                # print(f'old : {oldmovie[i]}\nnew : {movietitle[i]}')
                if oldmovie[i] != movietitle[i]:
                    numbermovie += 1
            for i in range(len(oldseries)):
                if oldseries[i] != seriestitle[i]:
                    numberseries += 1
            with open(f'{str(Path.home())}/.downloads.json', 'w') as fp:
                before['historymovie'][0] = movietitle
                before['historyseries'][0] = seriestitle
                json.dump(before, fp)
            return numbermovie, numberseries, '1'
    else:
        movietitle = []
        seriestitle = []
        for i in range(2, 5):
            reqmovies = requests.get(f"https://worldsubtitle.info/category/movies/page/{i}")
            reqseries = requests.get(f"https://worldsubtitle.info/category/tv-series/page/{i}")
            soupmovies = BeautifulSoup(reqmovies.content, 'html.parser')
            soupseries = BeautifulSoup(reqseries.content, 'html.parser')
            for div in soupmovies.find_all('div', class_='cat-post-titel'):
                for a in div.find_all('a'):
                    movietitle.append(a.get_text())
            for div in soupseries.find_all('div', class_='cat-post-titel'):
                for a in div.find_all('a'):
                    seriestitle.append(a.get_text())

        for i in range(len(movietitle)):
            movietitle[i] = remove(movietitle[i])
        for i in range(len(seriestitle)):
            seriestitle[i] = remove(seriestitle[i])
        with open(f'{str(Path.home())}/.downloads.json', 'r') as fp:
            all = json.load(fp)
        all['historymovie'].append(movietitle)
        all['historyseries'].append(seriestitle)
        with open(f'{str(Path.home())}/.downloads.json', 'w') as fp:
            json.dump(all, fp)
        return len(movietitle), len(seriestitle), '1'


def save_downloads(newdw):
    with open(f'{str(Path.home())}/.downloads.json', 'r') as fp:
        downloads = json.load(fp)

    downloads['Downloads'].append(newdw)
    with open(f'{str(Path.home())}/.downloads.json', 'w') as fp:
        json.dump(downloads, fp)


def remove(string):
    return string.strip()


def base(str):
    str_bytes = str.encode('ascii')
    base64_bytes = base64.b64encode(str_bytes)
    base64_str = base64_bytes.decode('ascii')
    return base64_str


def debase(str):
    base64_bytes = str.encode('ascii')
    str_bytes = base64.b64decode(base64_bytes)
    str_dec = str_bytes.decode('ascii')
    return str_dec


def search(name):
    movietitle = []
    movielink = []
    for i in range(1, 11):
        req = requests.get(f"{base_url}{i}?s={name}")
        soup = BeautifulSoup(req.content, 'html.parser')
        for div in soup.find_all('div', class_='cat-post-titel'):
            for a in div.find_all('a'):
                movielink.append(a['href'])
                movietitle.append(a.get_text())
    if len(movietitle) != 0:
        for i in range(len(movietitle)):
            movietitle[i] = remove(movietitle[i])
        movietitle.append("Back To Home Menu")
        choice = [
            {
                'type': 'list',
                'name': 'choice',
                'message': 'Choose Your Movie/Serie:',
                'choices': movietitle,
            }
        ]
        answer = prompt(choice, style=style)
        if answer['choice'] == "Back To Home Menu":
            return "Back To Home Menu"
        else:
            index = movietitle.index(answer['choice'])
            link = movielink[index]
            return link
    else:
        return "0 Record Found."


def download(link, directory):
    downloadlink = []
    name = []
    req = requests.get(link)
    soup = BeautifulSoup(req.content, 'html.parser')
    for div in soup.find_all('div', class_='new-link-3'):
        for a in div.find_all('a'):
            downloadlink.append(a['href'])

    for i in range(len(downloadlink)):
        hund = downloadlink[i]
        a = urlparse(hund)
        name.append(os.path.basename(a.path))

    for i in range(len(name)):
        if "_WorldSubtitle.zip" in name[i]:
            name[i] = name[i].replace("_WorldSubtitle.zip", "")
        if ".WWW.WORLDSUBTITLE.IN.zip" in name[i]:
            name[i] = name[i].replace(".WWW.WORLDSUBTITLE.IN.zip", "")
        if "_Worldsubtitle.zip" in name[i]:
            name[i] = name[i].replace("_Worldsubtitle.zip", "")
        if ".WWW.WORLDSUBTITLE.IN.rar" in name[i]:
            name[i] = name[i].replace(".WWW.WORLDSUBTITLE.IN.rar", "")
        if ".Worldsubtitle.zip" in name[i]:
            name[i] = name[i].replace(".Worldsubtitle.zip", "")
        if ".WWW.WORLDSUBTITLE.COM.rar" in name[i]:
            name[i] = name[i].replace(".WWW.WORLDSUBTITLE.COM.rar", "")
        if ".WWW.WORLDSUBTITLE.NET.zip" in name[i]:
            name[i] = name[i].replace(".WWW.WORLDSUBTITLE.NET.zip", "")

    choice = [
        {
            'type': 'list',
            'name': 'choice',
            'message': 'Choose Your Subtitle/s:',
            'choices': name,
        }
    ]
    answer = prompt(choice, style=style)
    index = name.index(answer['choice'])
    linkdownload = downloadlink[index]
    hund = linkdownload
    a = urlparse(hund)
    filename = os.path.basename(a.path)
    destination = os.path.join(directory, name[index])
    date = datetime.datetime.now().strftime('%Y-%m-%d%H:%M:%S.%f')
    downloads = {
        "Name": name[index],
        "Link": base(linkdownload),
        "Date": date
    }
    save_downloads(downloads)
    if ".rar" in filename:
        wget.download(linkdownload, out=f"{destination}_SSD.rar")
    if ".zip" in filename:
        wget.download(linkdownload, out=f"{destination}_SSD.zip")
    print(f"\n{bcolors.GREEN}Subtitle Downloaded.{bcolors.ENDC}")
    time.sleep(2)
    screencls()


def main():
    files = '{}/.conf.json'.format(str(Path.home()))
    check = os.path.isfile(files)
    if check:
        with open(f'{str(Path.home())}/.conf.json', 'r') as fp:
            conf = json.load(fp)
        movie = 0
        series = 0
        helper = ''
        if conf['first'] == 'True':
            movie, series, helper = get_new_subtitles(firsttime=True)
            conf['directory']['path'] = str(Path.home() / 'Downloads')
            conf['first'] = 'False'
            with open(f'{str(Path.home())}/.conf.json', 'w') as fp:
                json.dump(conf, fp)
        elif conf['first'] == 'False':
            movie, series, helper = get_new_subtitles(firsttime=False)
        ssd = Figlet(font='slant')
        while True:
            os.system('clear')
            if helper == '0':
                print(f"{bcolors.HEADER}{ssd.renderText('SSubDown')}{bcolors.OKBLUE}New Movie Subtitle Added: {bcolors.WARNING}No new movie subtitles added{bcolors.OKBLUE}->Previously added: {movie}\n{bcolors.BLUE}New Series Subtitle Added: {bcolors.WARNING}No new series subtitles added{bcolors.OKBLUE}->Previously added: {series}{bcolors.ENDC}")
            elif helper == '1':
                print(f"{bcolors.HEADER}{ssd.renderText('SSubDown')}{bcolors.OKBLUE}New Movie Subtitle Added: {movie}\n{bcolors.BLUE}New Series Subtitle Added: {series}{bcolors.ENDC}")
            info = [
                {
                    'type': 'list',
                    'name': 'info',
                    'message': 'Choose:',
                    'choices': ['Search For Subtitle', 'Show Your Downloads', 'Settings', 'check For Update', 'About', 'Donate', 'Exit'],
                }
            ]
            ans = prompt(info, style=style)

            if ans['info'] == 'Search For Subtitle':
                name = [
                    {
                        'type': 'list',
                        'name': 'search',
                        'message': 'Choose: ',
                        'choices': ['Search For Movie/Serie:', 'Back To Home Menu']
                    },
                ]
                answer = prompt(name, style=style)
                if answer['search'] == "Search For Movie/Serie:":
                    name = [
                        {
                            'type': 'input',
                            'name': 'name',
                            'message': 'Enter Name Of Movie/Serie:'
                        },
                    ]
                    ans = prompt(name, style=style)
                    link = search(ans['name'])
                    if link == "0 Record Found.":
                        print(link)
                    elif link == "Back To Home Menu":
                        screencls()
                    else:
                        with open(f'{str(Path.home())}/.conf.json', 'r') as fp:
                            conf = json.load(fp)
                            download(link, conf['directory']['path'])
                elif answer['search'] == "Back To Home Menu":
                    screencls()

            elif ans['info'] == 'Show Your Downloads':
                alldownloadsname = []
                alldownloadsdate = []
                with open(f'{str(Path.home())}/.downloads.json', 'r') as fp:
                    downloads = json.load(fp)
                if len(downloads['Downloads']) != 0:
                    for i in range(len(downloads['Downloads'])):
                        alldownloadsname.append(downloads['Downloads'][i]['Name'])
                        alldownloadsdate.append(downloads['Downloads'][i]['Date'])
                    for i in range(len(alldownloadsname)):
                        alldownloadsname[i] = f"{alldownloadsname[i]}  |  Download Date: {alldownloadsdate[i]}"
                    alldownloadsname.append("Back To Home Menu")
                    show = [
                        {
                            'type': 'list',
                            'name': 'show',
                            'message': 'Choice',
                            'choices': ['Just Show Downloads History', 'Download Subtitle From History',
                                        'Back To Home Menu']
                        }
                    ]
                    ans = prompt(show, style=style)
                    if ans['show'] == "Just Show Downloads History":
                        show = [
                            {
                                'type': 'list',
                                'name': 'show',
                                'message': 'This Is All Downloads History',
                                'choices': alldownloadsname
                            }
                        ]
                        ans = prompt(show, style=style)
                        if ans['show'] == "Back To Home Menu":
                            screencls()
                    elif ans['show'] == "Download Subtitle From History":
                        show = [
                            {
                                'type': 'list',
                                'name': 'show',
                                'message': 'This Is All Downloads History Choose',
                                'choices': alldownloadsname
                            }
                        ]
                        ans = prompt(show, style=style)
                        with open(f'{str(Path.home())}/.downloads.json', 'r') as fp:
                            down = json.load(fp)
                        with open(f'{str(Path.home())}/.conf.json', 'r') as fp:
                            conf = json.load(fp)
                        for i in range(len(down['Downloads'])):
                            if down['Downloads'][i]['Name'] in ans['show']:
                                link = down['Downloads'][i]['Link']
                                destination = os.path.join(conf['directory']['path'], ans['show'])
                                delink = debase(link)
                                if ".rar" in delink:
                                    wget.download(delink, out=f"{destination}_SSD.rar")
                                if ".zip" in delink:
                                    wget.download(delink, out=f"{destination}_SSD.zip")
                                print(f"\n{bcolors.GREEN}  Subtitle Downloaded.{bcolors.ENDC}")
                                time.sleep(2)
                    elif ans['show'] == "Back To Home Menu":
                        screencls()
                else:
                    print(f"{bcolors.WARNING}Nothing For Show!.")
                    time.sleep(3)
                    screencls()
            elif ans['info'] == 'Settings':
                setting = [
                    {
                        'type': 'list',
                        'name': 'setting',
                        'message': 'choice Option',
                        'choices': ['Change Download Directory Path', 'Show Settings', 'Back To Home Menu']
                    }
                ]
                ans = prompt(setting, style=style)
                if ans['setting'] == "Change Download Directory Path":
                    while True:
                        path = []
                        if PLATFORM == "Linux":
                            path = [
                                {
                                    'type': 'input',
                                    'name': 'path',
                                    'message': 'Enter Path(Ex Linux: /home/Username/Downloads): ',
                                }
                            ]
                        if PLATFORM == "Windows":
                            path = [
                                {
                                    'type': 'input',
                                    'name': 'path',
                                    'message': 'Enter Path(Ex Windows: C:/Users/Myname/Downloads): ',
                                }
                            ]
                        anspath = prompt(path, style=style)
                        if anspath['path'] in ['/home', '/home/', 'home/', 'home', '', '/']:
                            print(f"""
                            {bcolors.WARNING}Cont Change Download Directory To This Directory""")
                            continue
                        elif anspath['path'][-1] == '/':
                            anspath['path'] = anspath['path'][:-1]
                            auth = [
                                {
                                    'type': 'input',
                                    'name': 'auth',
                                    'message': 'Confirm This Path ({}) Y/n: '.format(anspath['path']),
                                }
                            ]
                            auth = prompt(auth, style=style)
                            if auth['auth'] in ['', 'Y', 'y', 'yes', 'YES']:
                                with open(f'{str(Path.home())}/.conf.json', 'r') as fp:
                                    conf = json.load(fp)
                                    conf['directory'] = anspath
                                with open(f'{str(Path.home())}/.conf.json', 'w') as fp:
                                    json.dump(conf, fp)
                                print(f"{bcolors.OKGREEN}Download Directory Changed Success.{bcolors.ENDC}")
                                time.sleep(3)
                                break
                            else:
                                print(f"{bcolors.WARNING}Download Directory Not Changed")
                                time.sleep(3)
                                break
                        else:
                            auth = [
                                {
                                    'type': 'input',
                                    'name': 'auth',
                                    'message': 'Confirm This Path ({}) Y/n: '.format(anspath['path']),
                                }
                            ]
                            auth = prompt(auth, style=style)
                            if auth['auth'] in ['', 'Y', 'y', 'yes', 'YES']:
                                with open(f'{str(Path.home())}/.conf.json', 'r') as fp:
                                    conf = json.load(fp)
                                    conf['directory'] = anspath
                                with open(f'{str(Path.home())}/.conf.json', 'w') as fp:
                                    json.dump(conf, fp)
                                print(f"{bcolors.OKGREEN}Download Directory Changed Success.{bcolors.ENDC}")
                                time.sleep(3)
                                break
                            else:
                                print(f"{bcolors.WARNING}Download Directory Not Changed")
                                time.sleep(3)
                                break
                    screencls()

                elif ans['setting'] == "Show Settings":
                    with open(f'{str(Path.home())}/.conf.json', 'r') as fp:
                        conf = json.load(fp)
                    print(f"""
                    {bcolors.WARNING}First      :  False{bcolors.ENDC}
                    {bcolors.OKGREEN}Directory  :  {conf['directory']['path']}{bcolors.ENDC}
                    """)
                    back = [
                        {
                            'type': 'list',
                            'name': 'back',
                            'message': 'Back To Home Menu',
                            'choices': ['Back To Home Menu']
                        }
                    ]
                    answer = prompt(back, style=style)
                    if answer['back'] == 'Back To Home Menu':
                        screencls()
                elif ans['setting'] == "Back To Home Menu":
                    screencls()
            elif ans['info'] == 'About':
                print(f"""
                Application : {bcolors.HEADER}Sadegh Subtitle Downloader{bcolors.ENDC}
                Created By  : {bcolors.OKGREEN}Sullivan{bcolors.ENDC}
                Email       : {bcolors.OKBLUE}salar.z@outlook.de{bcolors.ENDC}
                Discription : {bcolors.WARNING}SsubDownloader A Tool For Download FA Subtitle{bcolors.ENDC}
                Version     : {bcolors.BOLD}0.2{bcolors.ENDC}
                """)
                back = [
                    {
                        'type': 'list',
                        'name': 'back',
                        'message': 'Back to menu',
                        'choices': ['Back To Home Menu']
                    }
                ]
                answer = prompt(back, style=style)
                if answer['back'] == 'Back To Home Menu':
                    screencls()

            elif ans['info'] == 'Donate':
                print(f"""
                {bcolors.WARNING}This Field Is Disabled.{bcolors.ENDC}
                """)
                back = [
                    {
                        'type': 'list',
                        'name': 'back',
                        'message': 'Back to menu',
                        'choices': ['Back To Home Menu']
                    }
                ]
                answer = prompt(back, style=style)
                if answer['back'] == 'Back To Home Menu':
                    screencls()
            elif ans['info'] == 'check For Update':
                with open(f'{str(Path.home())}/.conf.json', 'r') as fp:
                    conf = json.load(fp)
                req = requests.get("https://raw.githubusercontent.com/Epic-R-R/SsubDownloader/Sullivan/package.json")
                data = json.loads(req.content)
                version = data['versions'][-1]
                if float(version) == conf['version']:
                    print(f'''
                    {bcolors.GREEN}You use latest version{bcolors.ENDC}
                    ''')
                    time.sleep(3)
                    screencls()
                if float(version) > conf['version']:
                    print(f'''
                    {bcolors.WARNING}You use older version{bcolors.ENDC}
                    {bcolors.FAIL}Download new version from here: https://github.com/Epic-R-R/SsubDownloader{bcolors.ENDC}
                    ''')
                    time.sleep(3)
                    screencls()
            elif ans['info'] == 'Exit':
                sys.exit(0)
    else:
        with open(f'{str(Path.home())}/.conf.json', 'w') as fp:
            dic = {"first": "True", "directory": {"path": ""}, "version": 0.2}
            json.dump(dic, fp)
        with open(f'{str(Path.home())}/.downloads.json', 'w') as fp:
            dic = {"Downloads": [], "historymovie": [], "historyseries": []}
            json.dump(dic, fp)
        screencls()
        main()


if __name__ == "__main__":
    main()

