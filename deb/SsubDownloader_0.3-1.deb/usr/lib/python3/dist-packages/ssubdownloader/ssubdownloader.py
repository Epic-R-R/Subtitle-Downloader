from bs4 import BeautifulSoup
from PyInquirer import (
    Token,
    ValidationError,
    Validator,
    prompt,
    style_from_dict,
)
from urllib.parse import urlparse
from pyfiglet import Figlet
from pathlib import Path
import hashlib
import os.path
import requests
import re
import os
import sys
import wget
import time
import platform
import json
import datetime
import base64
import webbrowser


# get platform name
PLATFORM = platform.system()
# download path
PATH = "{}/Downloads/SsubDownloader".format(str(Path.home()))
# url for search and download subtitles
base_url = "https://worldsubtitle.info/page/"


# create class for check Empty Field in input
class EmptyValidator(Validator):
    def validate(self, value):
        if len(value.text):
            return True
        else:
            raise ValidationError(
                message="You can't leave this blank", cursor_position=len(value.text)
            )


# create class for check email valid
class EmailValidator(Validator):
    pattern = r"\"?([-a-zA-Z0-9.`?{}]+@\w+\.\w+)\"?"

    def validate(self, email):
        if len(email.text):
            if re.match(self.pattern, email.text):
                return True
            else:
                raise ValidationError(
                    message="Invalid email",
                    cursor_position=len(email.text))
        else:
            raise ValidationError(
                message="You can't leave this blank",
                cursor_position=len(email.text))


# create class for terminal color
class bcolors:
    GREEN = "\033[32m"
    HEADER = "\033[95m"
    MAGENTA = "\033[35m"
    OKBLUE = "\033[94m"
    BLUE = "\033[34m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"


# create style for terminal
style = style_from_dict(
    {
        Token.QuestionMark: "#fac731 bold",
        Token.Answer: "#4688f1 bold",
        Token.Instruction: "",  # default
        Token.Separator: "#cc5454",
        Token.Selected: "#0abf5b",  # default
        Token.Pointer: "#673ab7 bold",
        Token.Question: "",
    }
)

# create func for get user name
def get_name():
    with open(f"{PATH}/.account.json", "r") as fp:
        data = json.load(fp)
    if data['account'] == 'False':
        return 'Guest'
    else:
        return data['info']['name']

# create func for clear screen
def screencls():
    if PLATFORM == "Linux" or PLATFORM == "Darwin":
        os.system("clear")
    if PLATFORM == "Windows":
        os.system("cls")


# create func for save download History
def save_downloads(newdw):
    with open(f"{PATH}/.downloads.json", "r") as fp:
        downloads = json.load(fp)

    downloads["Downloads"].append(newdw)
    with open(f"{PATH}/.downloads.json", "w") as fp:
        json.dump(downloads, fp)


# create func for remove space from string
def remove(string):
    return string.strip()


# create func for string encode base64
def base(str):
    str_bytes = str.encode("ascii")
    base64_bytes = base64.b64encode(str_bytes)
    base64_str = base64_bytes.decode("ascii")
    return base64_str


# create func for string decode base64
def debase(str):
    base64_bytes = str.encode("ascii")
    str_bytes = base64.b64decode(base64_bytes)
    str_dec = str_bytes.decode("ascii")
    return str_dec


# create func for search
def search(name):
    movietitle = []
    movielink = []
    for i in range(1, 11):
        req = requests.get(f"{base_url}{i}?s={name}")
        soup = BeautifulSoup(req.content, "html.parser")
        for div in soup.find_all("div", class_="cat-post-titel"):
            for a in div.find_all("a"):
                movielink.append(a["href"])
                movietitle.append(a.get_text())
    if len(movietitle) != 0:
        for i in range(len(movietitle)):
            movietitle[i] = remove(movietitle[i])
        movietitle.append("Back To Home Menu")
        choice = [
            {
                "type": "list",
                "name": "choice",
                "message": "Choose Your Movie/Serie:",
                "choices": movietitle,
            }
        ]
        answer = prompt(choice, style=style)
        if answer["choice"] == "Back To Home Menu":
            return "Back To Home Menu"
        else:
            index = movietitle.index(answer["choice"])
            link = movielink[index]
            return link
    else:
        return "0 Record Found."


# create func for download subtitle
def download(link, directory):
    downloadlink = []
    name = []
    req = requests.get(link)
    soup = BeautifulSoup(req.content, "html.parser")
    for div in soup.find_all("div", class_="new-link-3"):
        for a in div.find_all("a"):
            downloadlink.append(a["href"])

    for i in range(len(downloadlink)):
        hund = downloadlink[i]
        a = urlparse(hund)
        name.append(os.path.basename(a.path))

    for i in range(len(name)):
        if "_WorldSubtitle.zip" in name[i]:
            name[i] = name[i].replace("_WorldSubtitle.zip", "")
        if ".WWW.WORLDSUBTITLE.IN.zip" in name[i]:
            name[i] = name[i].replace(".WWW.WORLDSUBTITLE.IN.zip", "")
        if "_Worldsubtitle.zip" in name[i]:
            name[i] = name[i].replace("_Worldsubtitle.zip", "")
        if ".WWW.WORLDSUBTITLE.IN.rar" in name[i]:
            name[i] = name[i].replace(".WWW.WORLDSUBTITLE.IN.rar", "")
        if ".Worldsubtitle.zip" in name[i]:
            name[i] = name[i].replace(".Worldsubtitle.zip", "")
        if ".WWW.WORLDSUBTITLE.COM.rar" in name[i]:
            name[i] = name[i].replace(".WWW.WORLDSUBTITLE.COM.rar", "")
        if ".WWW.WORLDSUBTITLE.NET.zip" in name[i]:
            name[i] = name[i].replace(".WWW.WORLDSUBTITLE.NET.zip", "")

    choice = [
        {
            "type": "list",
            "name": "choice",
            "message": "Choose Your Subtitle/s:",
            "choices": name,
        }
    ]
    answer = prompt(choice, style=style)
    index = name.index(answer["choice"])
    linkdownload = downloadlink[index]
    hund = linkdownload
    a = urlparse(hund)
    filename = os.path.basename(a.path)
    destination = os.path.join(directory, name[index])
    date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    downloads = {"Name": name[index], "Link": base(linkdownload), "Date": date}
    save_downloads(downloads)
    if ".rar" in filename:
        wget.download(linkdownload, out=f"{destination}_SSD.rar")
    if ".zip" in filename:
        wget.download(linkdownload, out=f"{destination}_SSD.zip")
    print(f"\n{bcolors.GREEN}Subtitle Downloaded.{bcolors.ENDC}")
    time.sleep(2)
    screencls()



# create main func
def main():
    check = os.path.isdir(PATH)
    if check:
        with open(f"{PATH}/.conf.json", "r") as fp:
            conf = json.load(fp)
        if conf["first"] == "True":
            conf["directory"]["path"] = str(Path.home() / "Downloads/SsubDownloader")
            conf["first"] = "False"
            with open(f"{PATH}/.conf.json", "w") as fp:
                json.dump(conf, fp)
        ssd = Figlet(font="slant")
        while True:
            os.system("clear")
            print(f"{bcolors.HEADER}{ssd.renderText('SSD')}{bcolors.WARNING}Welcome {get_name()}{bcolors.OKBLUE}")
            info = []
            if get_name() == "Guest":
                info = [
                    {
                    "type": "list",
                    "name": "info",
                    "message": "Choose:",
                    "choices": [
                        "Search For Subtitle",
                        "Settings",
                        "Account",
                        "Check For Update",
                        "About",
                        "Donate",
                        "Exit",
                        ],
                    }
                ]
            else:
                info = [
                    {
                    "type": "list",
                    "name": "info",
                    "message": "Choose:",
                    "choices": [
                        "Search For Subtitle",
                        "Show Your Downloads",
                        "Settings",
                        "Account",
                        "Check For Update",
                        "About",
                        "Donate",
                        "Exit",
                        ],
                    }
                ]
            ans = prompt(info, style=style)

            if ans["info"] == "Search For Subtitle":
                name = [
                    {
                        "type": "list",
                        "name": "search",
                        "message": "Choose: ",
                        "choices": ["Search For Movie/Serie:", "Back To Home Menu"],
                    },
                ]
                answer = prompt(name, style=style)
                if answer["search"] == "Search For Movie/Serie:":
                    name = [
                        {
                            "type": "input",
                            "name": "name",
                            "message": "Enter Name Of Movie/Serie:",
                            "validate": EmptyValidator,
                        },
                    ]
                    ans = prompt(name, style=style)
                    link = search(ans["name"])
                    if link == "0 Record Found.":
                        print(link)
                    elif link == "Back To Home Menu":
                        screencls()
                    else:
                        with open(f"{PATH}/.conf.json", "r") as fp:
                            conf = json.load(fp)
                            download(link, conf["directory"]["path"])
                elif answer["search"] == "Back To Home Menu":
                    screencls()
            elif ans["info"] == "Show Your Downloads":
                alldownloadsname = []
                alldownloadsdate = []
                with open(f"{PATH}/.downloads.json", "r") as fp:
                    downloads = json.load(fp)
                if len(downloads["Downloads"]) != 0:
                    for i in range(len(downloads["Downloads"])):
                        alldownloadsname.append(downloads["Downloads"][i]["Name"])
                        alldownloadsdate.append(downloads["Downloads"][i]["Date"])
                    show = [
                        {
                            "type": "list",
                            "name": "show",
                            "message": "Choice",
                            "choices": [
                                "Just Show Downloads History",
                                "Download Subtitle From History",
                                "Back To Home Menu",
                            ],
                        }
                    ]
                    ans = prompt(show, style=style)
                    if ans["show"] == "Just Show Downloads History":
                        # This Is All Downloads History
                        for i in range(len(alldownloadsname)):
                            print(f"""
                            {bcolors.BLUE}Name           : {bcolors.GREEN}{alldownloadsname[i]}
                            {bcolors.OKBLUE}Download Date  : {bcolors.OKGREEN}{alldownloadsdate[i]}
                            {bcolors.MAGENTA}=================================================={bcolors.ENDC}
                            """)
                        back = [
                            {
                                "type": "list",
                                "name": "back",
                                "message": "Back",
                                "choices": ['Back To Home Menu'],
                            }
                        ]
                        ans = prompt(back, style=style)
                        if ans["back"] == "Back To Home Menu":
                            screencls()
                    elif ans["show"] == "Download Subtitle From History":
                        show = [
                            {
                                "type": "list",
                                "name": "show",
                                "message": "This Is All Downloads History Choose",
                                "choices": alldownloadsname,
                            }
                        ]
                        ans = prompt(show, style=style)
                        with open(f"{PATH}/.downloads.json", "r") as fp:
                            down = json.load(fp)
                        with open(f"{PATH}/.conf.json", "r") as fp:
                            conf = json.load(fp)
                        for i in range(len(down["Downloads"])):
                            if down["Downloads"][i]["Name"] in ans["show"]:
                                link = down["Downloads"][i]["Link"]
                                destination = os.path.join(
                                    conf["directory"]["path"], ans["show"]
                                )
                                delink = debase(link)
                                if ".rar" in delink:
                                    wget.download(delink, out=f"{destination}_SSD.rar")
                                if ".zip" in delink:
                                    wget.download(delink, out=f"{destination}_SSD.zip")
                                print(
                                    f"\n{bcolors.GREEN}  Subtitle Downloaded.{bcolors.ENDC}"
                                )
                                time.sleep(2)
                    elif ans["show"] == "Back To Home Menu":
                        screencls()
                else:
                    print(f"{bcolors.WARNING}Nothing For Show!.")
                    time.sleep(3)
                    screencls()

            elif ans["info"] == "Settings":
                setting = [
                    {
                        "type": "list",
                        "name": "setting",
                        "message": "choice Option",
                        "choices": [
                            "Change Download Directory Path",
                            "Show Settings",
                            "Back To Home Menu",
                        ],
                    }
                ]
                ans = prompt(setting, style=style)
                if ans["setting"] == "Change Download Directory Path":
                    while True:
                        path = []
                        if PLATFORM == "Linux":
                            path = [
                                {
                                    "type": "input",
                                    "name": "path",
                                    "message": "Enter Path(Ex Linux: /home/Username/Downloads): ",
                                    "validate": EmptyValidator,
                                }
                            ]
                        if PLATFORM == "Windows":
                            path = [
                                {
                                    "type": "input",
                                    "name": "path",
                                    "message": "Enter Path(Ex Windows: C:/Users/Myname/Downloads): ",
                                    "validate": EmptyValidator,
                                }
                            ]
                        anspath = prompt(path, style=style)
                        if anspath["path"] in [
                            "/home",
                            "/home/",
                            "home/",
                            "home",
                            "",
                            "/",
                        ]:
                            print(
                                f"""
                            {bcolors.WARNING}Cont Change Download Directory To This Directory
                            """
                            )
                            continue
                        elif anspath["path"][-1] == "/":
                            anspath["path"] = anspath["path"][:-1]
                            auth = [
                                {
                                    "type": "input",
                                    "name": "auth",
                                    "message": "Confirm This Path ({}) Y/n: ".format(
                                        anspath["path"]
                                    ),
                                    "validate": EmptyValidator,
                                }
                            ]
                            auth = prompt(auth, style=style)
                            if auth["auth"] in ["", "Y", "y", "yes", "YES"]:
                                with open(f"{PATH}/.conf.json", "r") as fp:
                                    conf = json.load(fp)
                                    conf["directory"] = anspath
                                with open(f"{PATH}/.conf.json", "w") as fp:
                                    json.dump(conf, fp)
                                print(f"""
                                {bcolors.OKGREEN}Download Directory Changed Success.{bcolors.ENDC}
                                """)
                                time.sleep(3)
                                break
                            else:
                                print(
                                    f"{bcolors.WARNING}Download Directory Not Changed"
                                )
                                time.sleep(3)
                                break
                        else:
                            auth = [
                                {
                                    "type": "input",
                                    "name": "auth",
                                    "message": "Confirm This Path ({}) Y/n: ".format(
                                        anspath["path"]
                                    ),
                                    "validate": EmptyValidator,
                                }
                            ]
                            auth = prompt(auth, style=style)
                            if auth["auth"] in ["", "Y", "y", "yes", "YES"]:
                                with open(f"{PATH}/.conf.json", "r") as fp:
                                    conf = json.load(fp)
                                    conf["directory"] = anspath
                                with open(f"{PATH}/.conf.json", "w") as fp:
                                    json.dump(conf, fp)
                                print(
                                    f"{bcolors.OKGREEN}Download Directory Changed Success.{bcolors.ENDC}"
                                )
                                time.sleep(3)
                                break
                            else:
                                print(
                                    f"{bcolors.WARNING}Download Directory Not Changed"
                                )
                                time.sleep(3)
                                break
                    screencls()

                elif ans["setting"] == "Show Settings":
                    with open(f"{PATH}/.conf.json", "r") as fp:
                        conf = json.load(fp)
                    print(
                        f"""
                    {bcolors.WARNING}First      :  False{bcolors.ENDC}
                    {bcolors.OKGREEN}Directory  :  {conf['directory']['path']}{bcolors.ENDC}
                    """
                    )
                    back = [
                        {
                            "type": "list",
                            "name": "back",
                            "message": "Back To Home Menu",
                            "choices": ["Back To Home Menu"],
                        }
                    ]
                    answer = prompt(back, style=style)
                    if answer["back"] == "Back To Home Menu":
                        screencls()
                elif ans["setting"] == "Back To Home Menu":
                    screencls()

            elif ans["info"] == "About":
                print(
                    f"""
                Application : {bcolors.HEADER}Sadegh Subtitle Downloader{bcolors.ENDC}
                Created By  : {bcolors.OKGREEN}Sullivan{bcolors.ENDC}
                Email       : {bcolors.OKBLUE}salar.z@outlook.de{bcolors.ENDC}
                Discription : {bcolors.WARNING}SsubDownloader A Tool For Download FA Subtitle{bcolors.ENDC}
                Version     : {bcolors.BOLD}0.2{bcolors.ENDC}
                """
                )
                back = [
                    {
                        "type": "list",
                        "name": "back",
                        "message": "Back to menu",
                        "choices": ["Back To Home Menu"],
                    }
                ]
                answer = prompt(back, style=style)
                if answer["back"] == "Back To Home Menu":
                    screencls()

            elif ans["info"] == "Account":
                with open(f"{PATH}/.account.json", "r") as fp:
                    data = json.load(fp)
                if data["account"] == "False":
                    choice = [
                        {
                            "type": "list",
                            "name": "login",
                            "message": "Choose",
                            "choices": ["Sign in", "Sign up", "Back To Home Menu"],
                        }
                    ]
                    print(
                        f"""
                     {bcolors.WARNING}You Don't Have Account
                     """
                    )
                    ans = prompt(choice, style=style)
                    if ans["login"] == "Sign in":
                        accountInfo = [
                            {
                                "type": "input",
                                "name": "username",
                                "message": "Enter Username:",
                                "validate": EmptyValidator,
                            },
                            {
                                "type": "input",
                                "name": "password",
                                "message": "Enter Password:",
                                "validate": EmptyValidator,
                            },
                        ]
                        ans = prompt(accountInfo, style=style)
                        req = requests.get("http://api.ssubdownloader.ir/login.php?username={}&password={}".format(ans['username'], ans['password']))
                        data = json.loads(req.content)
                        if 'Username or password is wrong' in req.text:
                            print(f"""
                            {bcolors.WARNING}Username or Password is invalid.
                            """)
                            time.sleep(3)
                        else:
                            dic = {
                                "account": "True",
                                "info": {
                                    "username": f"{data['username']}",
                                    "password": f"{data['password']}",
                                    "email": f"{data['email']}",
                                    "name": f"{data['name']}",
                                    "avatar": f"{data['avatar']}"
                                },
                            }
                            with open(f"{PATH}/.account.json", "w") as fp:
                                json.dump(dic, fp)
                            print(f"""
                            {bcolors.GREEN}Login Success.
                            """)
                            time.sleep(3)
                            screencls()
                    elif ans["login"] == "Sign up":
                        accountInfo = [
                            {
                                "type": "input",
                                "name": "username",
                                "message": "Enter Your Username :",
                                "validate": EmptyValidator,
                            },
                            {
                                "type": "input",
                                "name": "password",
                                "message": "Enter Your Password :",
                                "validate": EmptyValidator,
                            },
                            {
                                "type": "input",
                                "name": "email",
                                "message": "Enter Your Email    :",
                                "validate": EmailValidator,
                            },
                            {
                                "type": "input",
                                "name": "name",
                                "message": "Enter Your Name     :",
                                "validate": EmptyValidator,
                            },
                        ]
                        ans = prompt(accountInfo, style=style)
                        req = requests.get("http://api.ssubdownloader.ir/register.php?username={}&password={}&email={}&name={}&".format(ans['username'], ans['password'], ans['email'], ans['name']))
                        response = json.loads(req.content)
                        if response['message'] == 'registration was successful':
                            dic = {
                                "account": "True",
                                "info": {
                                    "username": f"{ans['username']}",
                                    "password": f"{hashlib.md5(ans['password'].encode('utf-8')).hexdigest()}",
                                    "email": f"{ans['email']}",
                                    "name": f"{ans['name']}",
                                    "avatar": ""
                                },
                            }
                            with open(f"{PATH}/.account.json", "w") as fp:
                                json.dump(dic, fp)
                            print(f"""
                            {bcolors.GREEN}Your Account Created.
                            """)
                            time.sleep(3)
                            screencls()
                        elif response['message'] == 'username early exists':
                            print(f"""
                            {bcolors.WARNING}Username Early Exists
                            """)
                            time.sleep(3)
                    elif ans["login"] == "Back To Home Menu":
                        screencls()
                elif data["account"] == "True":
                    choice = [
                        {
                            "type": "list",
                            "name": "info",
                            "message": "Choose",
                            "choices": [
                                "Details",
                                "Update Information",
                                "Logout",
                                "Back To Home Menu",
                            ],
                        }
                    ]
                    ans = prompt(choice, style=style)
                    if ans["info"] == "Details":
                        print(f"""
                        {bcolors.BLUE}Name     : {bcolors.GREEN}{data['info']['name']}
                        {bcolors.OKBLUE}Username : {bcolors.OKGREEN}{data['info']['username']}
                        {bcolors.MAGENTA}Email    : {bcolors.WARNING}{data['info']['email']}
                        {bcolors.BLUE}Password : {bcolors.GREEN}{data['info']['password']}{bcolors.ENDC}
                        """)
                        back = [
                            {
                                "type": "list",
                                "name": "back",
                                "message": "Back",
                                "choices": ['Back To Home Menu'],
                            }
                        ]
                        ans = prompt(back, style=style)
                        if ans["back"] == "Back To Home Menu":
                            screencls()
                    elif ans["info"] == "Update Information":
                        info = [
                            {
                                "type": "list",
                                "name": "info",
                                "message": "Choice",
                                "choices": ['Change Email', 'Change Password', 'Back To Home Menu'],
                            }
                        ]
                        ans = prompt(info, style=style)
                        if ans['info'] == "Change Email":
                            infoemail = [
                                {
                                    "type": "input",
                                    "name": "email",
                                    "message": "Enter Your Email   :",
                                    "validate": EmailValidator
                                },
                                {
                                    "type": "input",
                                    "name": "password",
                                    "message": "Enter Your Password:",
                                    "validate": EmptyValidator
                                },
                            ]
                            ans = prompt(infoemail, style=style)
                            if hashlib.md5(ans['password'].encode('utf-8')).hexdigest() != data['info']['password']:
                                print(f"""
                                {bcolors.WARNING}Wrong Password, Try Again{bcolors.ENDC}
                                """)
                                time.sleep(3)
                                screencls()
                            elif hashlib.md5(ans['password'].encode('utf-8')).hexdigest() == data['info']['password']:
                                with open(f"{PATH}/.account.json", "r") as fp:
                                    data = json.load(fp)
                                data['info']['email'] = ans['email']
                                with open(f"{PATH}/.account.json", "w") as fp:
                                    json.dump(data, fp)
                                req = requests.get("http://api.ssubdownloader.ir/update.php?username={}&email={}".format(data['info']['username'], ans['email']))
                                print(f"""
                                {bcolors.GREEN}Email Changed successfully{bcolors.ENDC}
                                """)
                                time.sleep(2)
                        elif ans['info'] == "Change Password":
                            infopass = [
                                {
                                    "type": "input",
                                    "name": "oldpassword",
                                    "message": "Enter Your Password:",
                                    "validate": EmptyValidator
                                },
                            ]
                            ans = prompt(infopass, style=style)
                            if hashlib.md5(ans['oldpassword'].encode('utf-8')).hexdigest() == data['info']['password']:
                                newpass = [
                                    {
                                        "type": "input",
                                        "name": "newpassword",
                                        "message": "Enter New Password :",
                                        "validate": EmptyValidator
                                    },
                                ]
                                ans = prompt(newpass, style=style)
                                req = requests.get("http://api.ssubdownloader.ir/update.php?username={}&password={}".format(data['info']['username'], ans['newpassword']))
                                res = json.loads(req.content)
                                if res['message'] == "Passowrd updated successfully":
                                    with open(f"{PATH}/.account.json", "r") as fp:
                                        data = json.load(fp)
                                    data['info']['password'] = hashlib.md5(ans['newpassword'].encode('utf-8')).hexdigest()
                                    with open(f"{PATH}/.account.json", "w") as fp:
                                        json.dump(data, fp)
                                    print(f"""
                                    {bcolors.GREEN}Password Updated Successfully.
                                    """)
                                    time.sleep(3)
                            elif hashlib.md5(ans['oldpassword'].encode('utf-8')).hexdigest() != data['info']['password']:
                                print(f"""
                                {bcolors.WARNING}Password Is Invalid.
                                """)
                                time.sleep(3)
                        elif ans['info'] == "Back To Home Menu":
                            screencls()
                    elif ans["info"] == "Logout":
                        with open(f"{PATH}/.account.json", "w") as fp:
                            dic = {
                                "account": "False",
                                "info": {
                                    "username": "",
                                    "password": "",
                                    "email": "",
                                    "name": "",
                                    "avatar": ""
                                }
                            }
                            json.dump(dic, fp)
                            print(f"""
                            {bcolors.OKBLUE}Logout Completed Successfully
                            """)
                            time.sleep(2)
                    elif ans["info"] == "Back To Home Menu":
                        screencls()
            elif ans["info"] == "Donate":
                print(
                    f"""
                {bcolors.WARNING}This Field Is Disabled.{bcolors.ENDC}
                """
                )
                back = [
                    {
                        "type": "list",
                        "name": "back",
                        "message": "Back to menu",
                        "choices": ["Back To Home Menu"],
                    }
                ]
                answer = prompt(back, style=style)
                if answer["back"] == "Back To Home Menu":
                    screencls()

            elif ans["info"] == "Check For Update":
                with open(f"{PATH}/.conf.json", "r") as fp:
                    conf = json.load(fp)
                req = requests.get(
                    "https://raw.githubusercontent.com/Epic-R-R/SsubDownloader/Sullivan/package.json"
                )
                data = json.loads(req.content)
                version = data["versions"][-1]
                if float(version) == float(conf["version"]):
                    print(
                        f"""
                    {bcolors.GREEN}You use latest version{bcolors.ENDC}
                    """
                    )
                    time.sleep(3)
                    screencls()
                if float(version) > float(conf["version"]):
                    print(
                        f"""
                    {bcolors.WARNING}You use older version{bcolors.ENDC}
                    {bcolors.FAIL}Download new version from here: https://github.com/Epic-R-R/SsubDownloader{bcolors.ENDC}
                    """
                    )
                    webbrowser.open("https://github.com/Epic-R-R/SsubDownloader")
                    time.sleep(3)
                    screencls()

            elif ans["info"] == "Exit":
                sys.exit(0)
    else:
        os.mkdir(PATH)
        req = requests.get(
            "https://raw.githubusercontent.com/Epic-R-R/SsubDownloader/Sullivan/package.json"
        )
        data = json.loads(req.content)
        version = data["versions"][-1]
        dic = {"first": "False", "directory": {"path": f"{PATH}"}, "version": version}
        with open(f"{PATH}/.conf.json", "w") as fp:
            json.dump(dic, fp)
        with open(f"{PATH}/.downloads.json", "w") as fp:
            dic = {"Downloads": []}
            json.dump(dic, fp)
        with open(f"{PATH}/.account.json", "w") as fp:
            dic = {
                "account": "False",
                "info": {
                    "username": "", 
                    "password": "", 
                    "email": "", 
                    "name": "",
                    "avatar": ""
                },
            }
            json.dump(dic, fp)
        screencls()
        main()

if __name__ == "__main__":
    main()

